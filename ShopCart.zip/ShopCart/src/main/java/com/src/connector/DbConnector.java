package com.src.connector;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DbConnector {
	
	public DbConnector() {
		// TODO Auto-generated constructor stub
	}

	public Connection getConnection() throws Exception {
		Class.forName("com.mysql.cj.jdbc.Driver");
		Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/Tharak","Tharak","Tharak@438");
		return con;
	}
}
