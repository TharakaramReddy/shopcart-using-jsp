package com.src.controller;

import java.io.IOException;
import java.util.Random;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.src.bean.Products;
import com.src.dao.ProductDaoImpl;
import com.src.service.ProductService;
import com.src.service.ProductServiceImpl;

@WebServlet(value="/add")
public class AddController extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	ProductService service=new ProductServiceImpl();
	ProductDaoImpl dao=new ProductDaoImpl();
	Products pro=new Products();
	
	public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		System.out.println("1");
		Random random= new Random();
		int proId = random.nextInt(9999);
		System.out.println(proId);
		String proName = request.getParameter("productName");
		System.out.println(proName);
		String proCategory = request.getParameter("productCategory");
		System.out.println(proCategory);
		int proPrice = Integer.parseInt(request.getParameter("productPrice"));
		System.out.println(proPrice);
		
		pro.setProductId(proId);
		pro.setProductName(proName);
		pro.setProductCategory(proCategory);
		pro.setProductPrice(proPrice);
		System.out.println("2");
		
		if(pro.getProductId()==0||  pro.getProductName().isEmpty() || pro.getProductCategory().isEmpty() ||	pro.getProductPrice()==0) {
			
			RequestDispatcher req = request.getRequestDispatcher("add.jsp");
			System.out.print("fill all the fields");
			req.include(request, response);
			
		}
		
		try {
			
			if(service.AddProduct(pro)==1) {
				System.out.println("Registered successfully");
				RequestDispatcher req = request.getRequestDispatcher("Success.jsp");
				req.forward(request, response);
			}
			else {
				System.out.println("Error Registering");
				RequestDispatcher req = request.getRequestDispatcher("Error.jsp");
				req.forward(request, response);
			}
			
		} catch (Exception e) {
			
			e.printStackTrace();
		}
		
		
}
	protected  void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		 doPost(request, response);
	}
}
