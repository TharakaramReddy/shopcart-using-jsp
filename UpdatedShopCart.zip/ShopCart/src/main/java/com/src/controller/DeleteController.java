package com.src.controller;

import java.io.IOException;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.src.bean.Products;
import com.src.service.ProductService;
import com.src.service.ProductServiceImpl;

@WebServlet(value="/delete")
public class DeleteController extends HttpServlet {
	Products pro = new Products();
	ProductService productservice = new ProductServiceImpl();

	public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");

		System.out.println("$$$$$$$$$$$$$$$$$$$$$$$$$$");

		int proId = Integer.parseInt(request.getParameter("productId"));
		System.out.println(proId);

		pro.setProductId(proId);

		if (pro.getProductId() == 0) {

			RequestDispatcher req = request.getRequestDispatcher("delete.jsp");
			System.out.print("fill  the field");
			req.include(request, response);

		}
try {
		if (productservice.deleteProduct(pro) == 1) {
			RequestDispatcher req = request.getRequestDispatcher("deletesuccess.jsp");
			req.forward(request, response);
		} else {
			System.out.println("Error deleting");
			RequestDispatcher req = request.getRequestDispatcher("Error.jsp");
			req.forward(request, response);
		}
}
catch (Exception e) {
	// TODO: handle exception
}
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		doPost(request, response);
	}
}
