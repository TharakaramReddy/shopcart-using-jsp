package com.src.dao;

import java.sql.SQLException;
import java.util.List;

import com.src.bean.Products;

public interface ProductDao {

	public int AddProduct(Products pro) throws Exception;
	public List<Products> viewAllProducts() throws SQLException;
	public int updateProduct(Products pro) throws SQLException;
	public int deleteProduct(Products pro) throws SQLException;
	
}
