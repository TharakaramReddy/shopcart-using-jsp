package com.src.dao;



import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

import com.src.bean.Products;
import com.src.connector.DbConnector;

public class ProductDaoImpl implements ProductDao {
	
	Products products;
	DbConnector db;
	Connection connection;
	
	

	@Override
	public int AddProduct(Products pro) throws Exception {
		db=new DbConnector();
		connection =db.getConnection();
		System.out.println("  5     /////////////////////////////////////////////");
		String query= "insert into product values(?,?,?,?)";
		PreparedStatement ps=connection.prepareStatement(query);
		
		ps.setInt(1, pro.getProductId());
		ps.setString(2, pro.getProductName());
		ps.setString(3, pro.getProductCategory());
		ps.setInt(4,pro.getProductPrice());
		System.out.println("6");
		
		return ps.executeUpdate();

	}

	@SuppressWarnings("unchecked")
	@Override
	public List<Products> viewAllProducts() throws SQLException {
		
		List<Products> list=new ArrayList<>();
		try {
			db=new DbConnector();
			connection =db.getConnection();
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		PreparedStatement ps = connection.prepareStatement("SELECT * FROM product;");
		ResultSet rs=ps.executeQuery();
		while(rs.next()) {
			products=new Products();
			products.setProductId(rs.getInt("productId"));
			products.setProductName(rs.getString("productName"));
			products.setProductCategory(rs.getString("productCategory"));
			products.setProductPrice(rs.getInt("productPrice"));
			list.add(products);
			System.out.println(products.getProductId()+" "+products.getProductName()+" "
			+products.getProductCategory()+" "+products.getProductPrice());
		}
		return  list;
		

	}

	@Override
	public int updateProduct(Products pro) throws SQLException {
		
		PreparedStatement ps = null;
		int id=pro.getProductId();
		try {
			db=new DbConnector();
			connection =db.getConnection();
			
			 ps = connection.prepareStatement("Update product set productId=?,productName=?,"
					+ "productCategory=?,productPrice=? where productId="+id);
			
			 ps.setInt(1, pro.getProductId());
				ps.setString(2, pro.getProductName());
				ps.setString(3, pro.getProductCategory());
				ps.setInt(4,pro.getProductPrice());
			 
		}
		
		
		catch (Exception e) {
			e.printStackTrace();
		}
		
		
		return ps.executeUpdate();
		
		
	}

	@Override
	public int deleteProduct(Products pro) throws SQLException {
		
		PreparedStatement ps = null;
		int id=pro.getProductId();
		try {
			db=new DbConnector();
			connection =db.getConnection();
			
			 ps = connection.prepareStatement("delete from product where productId="+id);
			
		
		

	}
		catch (Exception e) {
			e.printStackTrace();
		}

		return ps.executeUpdate();
	
	
	}
}

	

