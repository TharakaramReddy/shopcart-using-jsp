package com.src.service;

import java.sql.SQLException;
import java.util.List;

import com.src.bean.Products;
import com.src.dao.ProductDao;
import com.src.dao.ProductDaoImpl;

public class ProductServiceImpl implements ProductService {
	ProductDao dao = new ProductDaoImpl();

	@Override
	public int AddProduct(Products pro) throws Exception {
		System.out.println("4");
		return dao.AddProduct(pro);

	}

	@Override
	public List<Products> viewAllProducts() throws SQLException {
		return dao.viewAllProducts();

	}

	@Override
	public int updateProduct(Products pro) throws SQLException {

		return dao.updateProduct(pro);
	}

	@Override
	public int deleteProduct(Products pro) throws SQLException {
		return dao.deleteProduct(pro);

	}

}
